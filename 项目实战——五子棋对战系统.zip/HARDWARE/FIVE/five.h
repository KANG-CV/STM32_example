#ifndef __FIVE_H
#define __FIVE_H	 
#include "sys.h"

void Main(void);
void rtp_intro(void);
void Draw(u16 x1,u16 y1,u16 x2,u16 y2);
void Introduce(void);
void xian(void);
void rtp_test(void);
void GameInit(void);


#endif

